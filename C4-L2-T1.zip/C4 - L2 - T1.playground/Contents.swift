/*:
# Extensions
## Swift avanzato
 
 Le estensioni aggiungono nuove funzionalità ad un type esistente sia esso `class`, un `struct`, un `enum` o un `protocol`. Questo include la possibilità di estendere anche i type di cui non disponiamo i sorgenti.
 
 Cosa possono fare:
 * Aggiungere nuove `computed property` di istanza e di type
 * Aggiungere nuovi metodi di istanza e di type
 * Aggiungere nuovi `initializer`
 * Definire nuovi `nested types` (tipi innestati)
 * Definire nuovi `subscripts`
 * Rendere un type conforme ad uno o più `protocol`
*/
extension Int {
    
}
