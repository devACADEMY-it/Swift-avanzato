/*:
# Methods requirements
## Swift avanzato

Si possono definire 3 tipi di *Methods Requirements*:
- Metodi generici
- Metodi mutating
- Metodi statici
*/
protocol Movable {
    func move()
    func move(steps: Int)
    
    mutating func set(name: String)
    
    static func hello()
}

struct User: Movable {
    func move() {
        print("L'utente si muove")
    }
    
    func move(steps: Int) {
        print("L'utente si muove di \(steps) passi")
    }
    
    mutating func set(name: String) {
        self.name = name
    }
    
    static func hello() {
        print("Ciao!")
    }
    
    var name: String
}

var u1 = User(name: "Massimo")
u1.move()
u1.move(steps: 3)
u1.set(name: "Maria")

User.hello()
