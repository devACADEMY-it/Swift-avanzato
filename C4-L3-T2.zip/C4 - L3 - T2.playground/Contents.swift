/*:
# Funzioni generiche
## Swift avanzato
*/
func exchange(v1: Int, v2: Int) -> (Int, Int) {
    return (v2, v1)
}

func genericExchange<T, X>(v1: T, v2: X) -> (X, T) {
    return (v2, v1)
}

genericExchange(v1: 4, v2: 5) // <---
genericExchange(v1: "ciao", v2: "hello") // <<
genericExchange(v1: "ciao", v2: 4)
genericExchange(v1: 4.0, v2: 4)
genericExchange(v1: 4.0, v2: "ciao")
