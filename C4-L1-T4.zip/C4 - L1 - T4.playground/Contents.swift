/*:
# Initializers requirements
## Swift avanzato
*/
protocol Identificabile {
    init(id: String)
    init(id: String, name: String)
}

struct Utente: Identificabile {
    init(id: String) {
        
    }
    
    init(id: String, name: String) {
        
    }
}

let u1 = Utente(id: "12345")
let u2 = Utente(id: "1234567", name: "Massimo")

class Persona: Identificabile {
    required init(id: String) {
    }
    
    required init(id: String, name: String) {
    }
}
