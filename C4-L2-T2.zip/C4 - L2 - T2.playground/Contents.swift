/*:
 # Extensions: aggiungere proprietà
 ## Swift avanzato
 */
extension Double {
    static let speedOfLightInMetersPerSecond: Double = 299_792_458
    static var speedOfLightInKmPerSecond: Double { speedOfLightInMetersPerSecond / 1_000 }
    
    var meters: Double { self }
    var km: Double { meters / 1_000 }
}

Double.speedOfLightInMetersPerSecond
Double.speedOfLightInKmPerSecond * 3


let d1: Double = 34

34.meters
34.km
