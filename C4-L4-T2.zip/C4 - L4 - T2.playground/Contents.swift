/*:
# Lanciare un errore
## Swift avanzato
*/
enum BoilerError: Error {
    case lowPressure
    case flameNotDetected
}

class Boiler {
    var isOn: Bool = false
    var isFlameOn = true
    var pressureLevel: Int = 2
    
    func switchOn(temp: Int) throws {
        // ... si accende la caldaia
        guard isFlameOn else {
            throw BoilerError.flameNotDetected
        }
        
        guard pressureLevel > 1 else {
            throw BoilerError.lowPressure
        }
        
        isOn = true
    }
}

let b1 = Boiler()
b1.isOn
//b1.switchOn(temp: 22)
b1.isOn
