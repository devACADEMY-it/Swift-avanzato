/*:
 # Protocol
 ## Swift avanzato
 
 Il `protocol` è un contratto in cui è definito l'elenco dei requisiti che un type deve rispettare se sottoscrive (*implementa* o *conforming/conform to*) il contratto.
 
 Nel *protocol* si possono inserire:
 - **Proprietà** (*Property requirements*)
 - **Metodi** (*Method requirements*)
 - **Initializer** (*Initializer requirements*)
 
 Enum, Struct e Class possono sottoscrivere un protocol.
 */
protocol Identificabile {
    
}

struct Person: Identificabile {
    
}
