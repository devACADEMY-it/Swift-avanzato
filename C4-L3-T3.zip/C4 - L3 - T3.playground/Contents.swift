/*:
# Type generici
## Swift avanzato
*/
struct Stack<Element> {
    private var elements: [Element] = []
    
    mutating func push(element: Element) {
        elements.append(element)
    }
    
    mutating func pop() -> Element? {
        return elements.popLast()
    }
}

var s1 = Stack<Int>()
var s2 = Stack<String>()

s1.push(element: 3)
s2.push(element: "Ciao")
