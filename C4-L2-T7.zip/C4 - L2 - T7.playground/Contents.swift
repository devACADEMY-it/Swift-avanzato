/*:
 # Default implementation of Protocols
 ## Swift avanzato
 */
protocol Movable {
    func move(steps: Int)
    func stop()
}

extension Movable {
    func move(steps: Int) {
        print("Si muove di \(steps) passi - extension")
    }
}

struct Person: Movable {
    func move(steps: Int) {
        print("Si muove di \(steps) passi - person")
    }
    
    func stop() {
        
    }
}

struct User: Movable {
    func stop() {
        
    }
}

let p1 = Person()
p1.move(steps: 3)
