/*:
 # Constraints and Conditional Conformance
 ## Swift avanzato
 */
protocol Movable {
    func move()
}

struct Person: Movable {
    let name: String
    
    func move() {
        print("La persona \(name) si muove")
    }
}

struct User {
    func move() {
        print("L'utente si muove")
    }
}

let people: [Person] = [ Person(name: "Massimo"),
                         Person(name: "Maria"),
                         Person(name: "Francesca")]

extension Array where Element: Movable {
    func moveAll() {
        self.forEach { e in
            e.move()
        }
    }
}

extension Array: Movable where Element: Movable {
    func move() {
        moveAll()
    }
}

func test(movable: Movable) {
    movable.move()
}

test(movable: Person(name: "Massimo"))
test(movable: people)
