/*:
# Intercettare un errore
## Swift avanzato
*/
enum BoilerError: Error {
    case lowPressure(Int, String)
    case flameNotDetected
}

class Boiler {
    var isOn: Bool = false
    var isFlameOn = true
    var pressureLevel: Int = 2
    
    func switchOn(temp: Int) throws {
        // ... si accende la caldaia
        guard isFlameOn else {
            throw BoilerError.flameNotDetected
        }
        
        guard pressureLevel > 1 else {
            throw BoilerError.lowPressure(pressureLevel, "pressure >= 2")
        }
        
        isOn = true
    }
}

func main() {
    let b1 = Boiler()
    b1.isOn
    b1.isFlameOn = true
    b1.pressureLevel = 0
    
    do {
        try b1.switchOn(temp: 22)
        print("Caldaia accesa!")
    } catch BoilerError.flameNotDetected {
        print("Errore: la fiamma è spenta")
    } catch BoilerError.lowPressure(let pressure, _) where pressure == 0 {
        print("Errore: la pressione dell'acqua è gravemente bassa, attivati sistemi di sicurezza")
    } catch BoilerError.lowPressure(let pressure, let info) {
        print("Errore: la pressione dell'acqua (\(pressure)) è troppo bassa. Richiesto: \(info)")
    } catch {
        print("Errore! \(error)")
    }
    
    print("Stato caldaia")
    b1.isOn
}

main()
