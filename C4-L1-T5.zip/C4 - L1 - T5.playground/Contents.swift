/*:
# Ereditarietà tra Protocol
## Swift avanzato
*/
protocol Movable {
    func move(steps: Int)
}

protocol Stoppable {
    func stop()
}

protocol Controllable: Movable, Stoppable {
    
}

struct Person: Controllable {
    func move(steps: Int) {
        
    }
    
    func stop() {
        
    }
}
