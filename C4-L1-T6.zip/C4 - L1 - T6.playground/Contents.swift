/*:
# Class-only Protocol
## Swift avanzato
*/
protocol Movable: AnyObject {
    func move()
}

class User: Movable {
    func move() {
    }
    
    var name: String = ""
}
