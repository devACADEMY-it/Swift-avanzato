/*:
# Programmazione Generica
## Swift avanzato
 
 La programmazione generica è uno stile di programmazione in cui gli algoritmi sono scritti in termini di tipi generici da specificare quando sono utilizzati.
 
 Gli obiettivi sono:
 * la riusabilità del codice
 * la riduzione della duplicazione del codice
 * l'ottimizzare e l'efficienza del codice
*/
func exchange(v1: Int, v2: Int) -> (Int, Int) {
    return (v2, v1)
}

func exchage(v1: Double, v2: Double) -> (Double, Double) {
    return (v2, v1)
}

func exchage(v1: String, v2: String) -> (String, String) {
    return (v2, v1)
}

exchange(v1: 3, v2: 6)
