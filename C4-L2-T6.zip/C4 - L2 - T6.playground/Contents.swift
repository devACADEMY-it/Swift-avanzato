/*:
 # Organizzare il codice con le estensioni
 ## Swift avanzato
 */
struct User {
    var name: String
    var email: String
}

extension User {
    func move() {
        // ..
    }
    
    func stop() {
        // ...
    }
}

extension User {
    init(name: String) {
        self.name = name
        self.email = ""
    }
    
    init(email: String) {
        self.name = ""
        self.email = email
    }
}

extension User: CustomStringConvertible {
    var description: String {
        return "name: \(name) - email: \(email)"
    }
}

extension User: CustomDebugStringConvertible {
    var debugDescription: String {
        return description
    }
}

let u1 = User(name: "", email: "")
let u2 = User(name: "Massimo")

u2.description
