/*:
 # Conformare un type ad un protocol
 ## Swift avanzato
 */
import Foundation

extension CGRect: CustomStringConvertible {
    public var description: String {
        return "x: \(minX) - y: \(minY) - width: \(width) - height: \(height)"
    }
}

extension CGPoint: CustomStringConvertible {
    public var description: String {
        return "x: \(x) - y: \(y)"
    }
}

let r1 = CGRect(x: 0, y: 0, width: 300, height: 20)
r1.description

let p1 = CGPoint(x: 10, y: 20)

func stampa(value: CustomStringConvertible) {
    print("il valore è: \(value.description)")
}


stampa(value: r1)
stampa(value: 4)
stampa(value: "ciao")
stampa(value: p1)
