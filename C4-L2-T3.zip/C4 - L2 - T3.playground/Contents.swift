/*:
 # Extensions: aggiungere metodi
 ## Swift avanzato
 */
extension Int {
    func repetitions(task: () -> Void) {
        for _ in 0..<self {
            task()
        }
    }
    
    static func sommma(v1: Int, v2: Int) -> Int { v1 + v2 }
}

5.repetitions {
    print("prova")
}

Int.sommma(v1: 3, v2: 6)
