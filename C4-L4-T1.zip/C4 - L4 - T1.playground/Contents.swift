/*:
# Definizione di Error
## Swift avanzato
*/
enum BoilerError: Error {
    case lowPressure
    case flameNotDetected
}
