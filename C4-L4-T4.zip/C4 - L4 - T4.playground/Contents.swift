/*:
# Sopprimere un errore
## Swift avanzato
*/
enum BoilerError: Error {
    case lowPressure(Int, String)
    case flameNotDetected
    case noSensorDetected
}

class Boiler {
    var isOn: Bool = false
    var isFlameOn = true
    var pressureLevel: Int = 2
    var isSensorDetected = true
    
    func switchOn(temp: Int) throws {
        // ... si accende la caldaia
        guard isFlameOn else {
            throw BoilerError.flameNotDetected
        }
        
        guard pressureLevel > 1 else {
            throw BoilerError.lowPressure(pressureLevel, "pressure >= 2")
        }
        
        isOn = true
    }
    
    func currentTemp() throws -> Int {
        guard isSensorDetected else {
            throw BoilerError.noSensorDetected
        }
        
        return 22
    }
}

func main() {
    let b1 = Boiler()
    b1.isOn
    b1.isFlameOn = true
    b1.pressureLevel = 0
    
    try? b1.switchOn(temp: 22)
    do {
        let tempValue = try b1.currentTemp()
    } catch {
        print("errore")
    }
    
    print("Stato caldaia")
    b1.isOn
}

main()
