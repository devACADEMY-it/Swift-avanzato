/*:
# Protocol: un esempio concreto
## Swift avanzato
*/
protocol Drawable {
    func render()
}

struct Square: Drawable {
    var side: Float
    
    func render() {
        print("  ⃞ ")
    }
}

struct Circle: Drawable {
    var radius: Float
    
    func render() {
        print("  ⃝ ")
    }
}

struct Line: Drawable {
    var len: Float
    
    func render() {
        print(" - ")
    }
}

struct Emoji: Drawable {
    func render() {
        print("😀")
    }
}

struct Diagram {
   private var shapes: [Drawable] = []
    
    mutating func add(shape: Drawable) {
        self.shapes.append(shape)
    }
    
    func render() {
        shapes.forEach { shape in
            shape.render()
        }
    }
}

let c1 = Circle(radius: 30)
let c2 = Circle(radius: 20)
let s1 = Square(side: 45)

var d1 = Diagram()
d1.add(shape: c1)
d1.add(shape: c2)
d1.add(shape: s1)
d1.add(shape: Line(len: 32))
d1.add(shape: Emoji())

d1.render()
