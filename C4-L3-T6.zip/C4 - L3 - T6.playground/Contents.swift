/*:
# Protocol generici con Associated Type
## Swift avanzato
*/
protocol Database {
    associatedtype Element
    associatedtype Key
    
    var firstElement: Element? { get }
    func save(element: Element)
    func get() -> Element
}

struct SqlDatabase: Database {
    typealias Key = String
    
    var firstElement: Int? { return nil }
    
    func save(element: Int) {
        
    }
    
    func get() -> Int {
        return 0
    }
}

struct OracleDatabase: Database {
    typealias Key = String
    var firstElement: String? { return nil }
    
    func save(element: String) {
    
    }
    
    func get() -> String {
        return ""
    }
}
