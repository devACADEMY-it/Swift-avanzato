/*:
 # Property requirements
 ## Swift avanzato
 
 Si possono definire 3 tipi di *Property Requirements*:
 - Proprietà in sola lettura
 - Proprietà in lettura e scrittura
 - Proprietà statiche
 */
protocol Identificabile {
    var id: String { get set }
    
    static var propertyId: String { get }
}

struct Person: Identificabile {
    static var propertyId: String = "Person.Id"
    
    var id: String
    var name: String
}

let p1 = Person(id: "id12", name: "Nome")

