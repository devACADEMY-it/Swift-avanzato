/*:
# Definire Type-Constraint
## Swift avanzato
*/
struct Stack<Element: CustomStringConvertible> {
    private var elements: [Element] = []
    
    mutating func push(element: Element) {
        elements.append(element)
    }
    
    mutating func pop() -> Element? {
        return elements.popLast()
    }
}

extension Stack: CustomStringConvertible {
    var description: String {
        return elements.map { $0.description }.joined(separator: ", ")
    }
}

struct User: CustomStringConvertible {
    var description: String = ""
}

var s1 = Stack<String>()
s1.push(element: "ciao")
s1.push(element: "mondo")

var s2 = Stack<User>()

s1.description
