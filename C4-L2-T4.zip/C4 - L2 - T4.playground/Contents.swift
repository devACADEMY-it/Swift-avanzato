/*:
 # Extensions: aggiungere init
 ## Swift avanzato
 */
import Foundation

extension CGPoint {
    init(value: Float) {
        self.init(x: CGFloat(value), y: CGFloat(value))
    }
}


let p1 = CGPoint(x: 3.4, y: 4.5)
p1.x
p1.y

let p2 = CGPoint(value: 6.9)
p2.x
p2.y
