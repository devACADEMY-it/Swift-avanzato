/*:
# Clausola Where
## Swift avanzato
*/
protocol Database {
    associatedtype Element
    
    func save(element: Element)
    func getAll() -> [Element]
}

func isEqual<D1: Database, D2: Database>(db1: D1, db2: D2) -> Bool where D1.Element: Comparable, D1.Element == D2.Element {
    let elements1 = db1.getAll()
    let elements2 = db2.getAll()
    
    guard elements1.count == elements2.count else {
        return false
    }
    
    for (index, element) in elements1.enumerated() {
        let e1 = element
        let e2 = elements2[index]
        
        if e1 != e2 {
            return false
        }
    }
    
    return true
}
